"""Sub-routers for AI-memory- API.

The file is intentionally empty: its mere presence makes
`memory_system.api.routes` a *regular* (non-namespace) package, so
`from memory_system.api.routes import ...` works on every interpreter.
See §6 «Modules» of the Python docs."""
