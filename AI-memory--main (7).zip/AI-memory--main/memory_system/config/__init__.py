"""Configuration package for Unified Memory System (contains settings)."""
